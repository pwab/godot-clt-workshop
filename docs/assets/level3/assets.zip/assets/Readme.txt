CC0-Assets sind toll! Bitte unterstütze die Künstler, in dem du dich bei Ihnen bedankst oder du sie in deinem Spiel mit erwähnst (bspw. in den Credits).
http://creativecommons.org/publicdomain/zero/1.0/

Kenny auf OpenGameArt.org (alles CC0)
- https://opengameart.org/content/platformer-art-deluxe
- https://opengameart.org/content/kenney-fonts
- https://opengameart.org/content/game-icons
- https://opengameart.org/content/onscreen-controls-8-styles

Musik bei FreePD (alles Public Domain = CC0)
https://freepd.com/
- Wakka Wakka - Written by Bryan Teoh. It's Yakity; it's saxity; It is everything you ever needed for a chase scene. This music is available for commercial and non-commercial purposes.
- Quick Metal Riff 1 - Written by Brett VanDonsel. Seven seconds of orgasmic metal glory! This music is available for commercial and non-commercial purposes.
- Magical Transition - Written by Kevin MacLeod. Magical and dark. Horror and fantasy melted together. This music is available for commercial and non-commercial purposes.

Sounds (alles CC0)
- clickclick
- huff
- huh
- klack
- uff

CLT (alles CC0, aber bitte die CLT mit in den Credits erwähnen ;)
- clt_background
- clt_farbverlauf
- clt_haus
- clt_tux